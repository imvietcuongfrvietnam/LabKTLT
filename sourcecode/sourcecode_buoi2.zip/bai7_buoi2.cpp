#include <iostream> 
using namespace std; 
//# viet h�m arr_sum 
/***************** 
	Trinh Viet Cuong 20224941
*****************/ 
template <typename T> //funtion Template
T arr_sum(T a[], int n, T b[], int m){
	T sum = a[0]; //sum khoi tao bang a[0]
	for(int i = 1;i<n;i++){
		sum += a[i]; //Cong cac phan tu trong mang a
	}
	for(int j = 0;j<m;j++){
		sum += b[j];//Cong cac phan tu trong mang b
	}
	return sum;
}
  int main() { 
	int val; 
	cin >> val; 
{
int a[] = {3, 2, 0, val}; 
        int b[] = {5, 6, 1, 2, 7}; 
        cout << arr_sum(a, 4, b, 5) << endl; 
    } 
    { 
        double a[] = {3.0, 2, 0, val * 1.0}; 
        double b[] = {5, 6.1, 1, 2.3, 7}; 
        cout << arr_sum(a, 4, b, 5) << endl; 
    } 
 
    return 0; 
} 
