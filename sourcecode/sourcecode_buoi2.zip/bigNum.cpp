#include <iostream>
#include <cstring>
#include <stack>
using namespace std;

struct bigNum {
    char sign;
    char num[101];
};

ostream& operator<<(ostream& os, const bigNum& a) {
    os << a.sign;
    int flag = 1;
    for (int i = 0; i < 101; i++) {
        if(a.num[i] == '0' && flag == 1) continue;
        flag--;
        os << a.num[i];
    }
    return os;
}

bigNum getBigNum(string s) {
    stack<char> ch;
    int i = 1;
    while (i < s.size()) {
        ch.push(s[i]);
        i++;
    }
    
    bigNum res;
    res.sign = s[0];
    int k = 100;
    while (!ch.empty() && k >= 0) {
        res.num[k] = ch.top();
        ch.pop();
        k--;
    }
    while (k >= 0) {
        res.num[k] = '0';
        k--;
    }
    
    return res;
}


bool operator==(const bigNum& a, const bigNum& b) {
    return (strcmp(a.num,b.num) && (a.sign == b.sign));
}
bool isGreater(const bigNum& a, const bigNum& b) {
    // So s�nh theo gi� tr? tuy?t d?i c?a c�c ch? s?
    for (int i = 0; i < 101; ++i) {
        if (a.num[i] > b.num[i]) return true;
        else if (a.num[i] < b.num[i]) return false;
    }
    return false;  // Hai s? b?ng nhau
}

bigNum operator+(const bigNum& a, const bigNum& b) {
    bigNum res;
    int borrow = 0;
    int flag = 100;
    // X�c d?nh s? l?n hon v� s? nh? hon
    const bigNum& larger = isGreater(a, b) ? a : b;
    const bigNum& smaller = isGreater(a, b) ? b : a;
    if(a.sign != b.sign) {
        for(int i = 100; i >= 0; i--){
            int diff = (larger.num[i] - '0') - (smaller.num[i] - '0') - borrow;
            if(diff < 0) {
                diff += 10;
                borrow = 1;
            } else {
                borrow = 0;
            }
            res.num[i] = diff + '0';
            if(res.num[i] != '0') flag = i;
        }
        if(borrow) {
            res.sign = '-';
            for(int i = flag; i < 100; i++){
                res.num[i] = 9 - (res.num[i] - '0') + '0';
            }
            res.num[100] = 10 - (res.num[100] - '0') + '0';
        } else {
            res.sign = '+';
        }
    }
    else {
        // 2 s? c�ng d?u
        int carry = 0;
        for (int i = 100; i >= 0; i--) {
            int sum = (a.num[i] - '0') + (b.num[i] - '0') + carry;
            res.num[i] = sum % 10 + '0';
            carry = sum / 10;
        }
        res.sign = a.sign;
    }
    return res;
}




bigNum operator- (const bigNum &b){
    bigNum res;
    res.sign = (b.sign == '+' ? '-' : '+');
    for(int i = 0; i < 101; i++){
        res.num[i] = '0' - (b.num[i] - '0');
    }
    return res;
}

bigNum operator-(const bigNum& a, const bigNum& b) {
    bigNum c = -b;
    return a + c;
}

bigNum operator*(const bigNum& a, const bigNum& b) {
    bigNum res;
    int carry = 0;
    res.sign = (a.sign == b.sign ? '+' : '-');
    for (int i = 100; i >= 0; i--) {
        res.num[i] = ((a.num[i] - '0') * (b.num[i] - '0') + carry) % 10 + '0';
        carry = ((a.num[i] - '0') * (b.num[i] - '0') + carry) / 10;
    }
    return res;
}

int main() {
    bigNum a, b;
    string s1;
    string s2;
    cin >> s1 >> s2;
    a = getBigNum(s1);
    b = getBigNum(s2);
    cout << "a + b = " << a + b << endl;
    return 0;
}

