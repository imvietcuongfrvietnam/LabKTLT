#include <iostream> 
#include <vector> 
#include <algorithm> 
#include <numeric> 
 
using namespace std; 
 
int main() { 
    int val1, val2; 
    cin >> val1 >> val2; 
    vector< vector<int> > a = { 
        {1, 3, 7}, 
        {2, 3, 4, val1}, 
        {9, 8, 15}, 
        {10, val2}, 
    }; 
 
    // S?p x?p c�c vector trong a theo t?ng c�c ph?n t? gi?m d?n
    //Trinh Viet Cuong 20224941
    sort(a.begin(), a.end(), [](const vector<int>& x, const vector<int>& y){ //S?p x?p m?ng a, truy?n v�o h�m sort 2 tham chi?u d?n c�c vector x v� y
            int sum1 = 0;
            for(int elem : x)
                sum1 += elem;

            int sum2 = 0;
            for(int elem : y)
                sum2 += elem;

            return sum1 > sum2;
         });
         
    for (const auto &v : a) { 
        for (int it : v) { 
            cout << it << ' '; 
        } 
        cout << endl; 
    } 
    return 0; 
}

