#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

struct Element {
    int key;
    int value;
};
//Trinh Viet Cuong 20224941
vector<Element> lst;

void inputList(){
    int tmp1, tmp2;
    while(cin >> tmp1 && cin >> tmp2){
        Element tmp;
        tmp.key = tmp1;
        tmp.value = tmp2;
        lst.push_back(tmp);
    }
}

void printList(){
    for(int i = 0; i < lst.size(); i++){
        cout << lst[i].key << " " << lst[i].value << endl;
    }
}

int main(){
    inputList();
    sort(lst.begin(), lst.end(), [] (const Element& a, const Element& b){ // Th�m const &
        if(a.value > b.value) return true;
        else if (a.value < b.value) return false;
        else {
            return a.key >= b.key;
        }
    });
    printList();
    return 0;
}

