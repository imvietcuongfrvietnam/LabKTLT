#include <iostream>
#include <ostream>
#include <math.h>
#include <iomanip>

using namespace std;

struct Complex {
    double real;
    double imag;
};

Complex operator + (Complex a, Complex b) {
    /****************
       Trinh Viet Cuong 20224941
    */
  	Complex res;
  	res.real = a.real + b.real;
  	res.imag = a.imag + b.imag;
  	return res;
    /*****************/
}

Complex operator - (Complex a, Complex b) {
    /*****************/
    Complex res;
    res.real = a.real - b.real;
    res.imag = a.imag - b.imag;
    return res;
    /*****************/
}

Complex operator * (Complex a, Complex b) {
    /*****************/
    Complex res;
    res.real = a.real * b.real - a.imag * b.imag;
    res.imag = a.real * b.imag + a.imag * b.real;
    return res;
    /*****************/
}

Complex operator / (Complex a, Complex b) {
    /*****************/
    Complex res;
	double modul = b.imag*b.imag + b.real*b.real;
	Complex lienhop;
	lienhop.real = b.real;
	lienhop.imag = -b.imag;
	res = lienhop * a;
	res.imag = res.imag / modul;
	res.real = res.real / modul;
	return res;
    /*****************/
}

ostream& operator << (ostream& out, const Complex &a) {
    out << '(' << std::setprecision(2) << a.real << (a.imag >= 0 ? '+' : '-') << std::setprecision(2) << fabs(a.imag) << 'i' << ')';
    return out;
}

int main() {
    double reala, realb, imga, imgb;
    cin >> reala >> imga;
    cin >> realb >> imgb;

    Complex a{reala, imga};
    Complex b{realb, imgb};

    cout << a << " + " << b << " = " << a + b << endl;
    cout << a << " - " << b << " = " << a - b << endl;
    cout << a << " * " << b << " = " << a * b << endl;
    cout << a << " / " << b << " = " << a / b << endl;

    return 0;
}
