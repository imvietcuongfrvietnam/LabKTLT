#include <stdio.h>

// S? d?ng n?p ch?ng h�m
int cube(int x) { // H�m t�nh b�nh phuong s? nguy�n
    return x * x * x;
    /************
    Trinh Viet Cuong 20224941
    */
}

double cube(double x) { // H�m t�nh b�nh phuong s? th?c
    return x * x * x;
}

int main() {
    int a;
    double b;
    scanf("%d %lf", &a, &b);
    printf("Int: %d\n", cube(a)); // In ra b�nh phuong s? nguy�n a
    printf("Double: %.2lf\n", cube(b)); // In ra b�nh phuong s? th?c b
    return 0;
}

