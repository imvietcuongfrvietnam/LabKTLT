#include<bits/stdc++.h>
using namespace std;
//Trinh Viet Cuong 20224941
typedef complex<double> Complex;
typedef vector<Complex> VectorComplex;

void input(int &n, int &m, VectorComplex &x, VectorComplex &y){
    cin >> n;
    for(int i = 0; i <= n; i++){
        int tmp;
        cin >> tmp;
        Complex myComplex(tmp, 0);
        x.push_back(myComplex);
    }

    cin >> m;
    for(int i = 0; i <= m; i++){
        int tmp;
        cin >> tmp;
        Complex myComplex(tmp, 0);
        y.push_back(myComplex);
    }
}

void fft(VectorComplex & a, bool revert){
    int n = (int)a.size();
    for(int i = 1, j = 0; i < n; ++i){
        int bit = n >> 1;
        while(j >= bit){
            j = j - bit;
            bit = bit >> 1;
        }
        j = j + bit;
        if (i < j)
            swap(a[i], a[j]);
    }
    for(int len = 2; len <= n; len <<= 1){
        double ang = 2 * M_PI / len;
        if(revert) ang = -ang;
        Complex wlen (cos(ang), sin(ang));
        for (int i = 0; i < n; i += len) {
            Complex w(1);
            for (int j = 0; j < len / 2; ++j) {
                Complex u = a[i + j],  v = a[i + j + len / 2] * w;
                a[i + j] = u + v;
                a[i + j + len / 2] = u - v;
                w = w * wlen;
            }
        }
    }
    if(revert)
        for(int i = 0; i < n; ++i)
            a[i] /= n;
}

int multiply(int n, int m, VectorComplex x, VectorComplex y){
    int p = 1;
    while(p < max(n, m)) p = p << 1;
    p = p << 1;
    x.resize(p);
    y.resize(p);
    fft(x, false);
    fft(y, false);
    VectorComplex h(p);
    for (int i = 0; i < p; i++)
        h[i] = x[i] * y[i];
    fft(h, true);
    int res = (int)(real(h[0]) + 0.5);
    for (int i = 1; i <= p; i++){
        res = res ^ (int)(real(h[i]) + 0.5);
    }
    return res;
}

int main(){
    int n, m;
    VectorComplex x, y;
    input(n, m, x, y);
    cout << multiply(n, m, x, y);
    printf("\n");
    return 0;
}

