#include <iostream>
#include <cstdio>
using namespace std;

int get_value(int x, int a = 2, int b = 1, int c = 0) { //dinh san a = 2, b = 1, c = 0 neu khong truyen tham so cho a,b,c
    /***********
    Trinh Viet Cuong 20224941
    */
    return a * x * x + b * x + c; //tra ve ket qua cua phuong trinh bac 2
}

int main() {
    int a = 2; //Gia tri mac dinh cua a
    int b = 1; //Gia tri mac dinh cua b
    int c = 0; //Gia tri mac dinh cua c
    int x;
    scanf("%d%d%d%d", &x, &a, &b, &c); //Nhap vao a,b,c va x tu ban phim
    printf("a=2, b=1, c=0: %d\n", get_value(x)); //truong hop su dung a, b, c mac dinh
    printf("a=%d, b=1, c=0: %d\n", a, get_value(x, a)); //truong hop su dung b, c mac dinh
    printf("a=%d, b=%d, c=0: %d\n", a, b, get_value(x, a, b)); //truong hop su dung c mac dinh
    printf("a=%d, b=%d, c=%d: %d\n", a, b, c, get_value(x, a, b, c)); //truong hop su dung tat ca tham so nhap tu ban phim
    return 0;
}

