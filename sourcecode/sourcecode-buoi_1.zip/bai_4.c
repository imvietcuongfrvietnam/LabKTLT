#include <stdio.h>

int counteven(int *arr, int n){
     //*****************
     // Trinh Viet Cuong 20224941
    int cnt = 0;
    
    int i = 0;
    
    for(i = 0;i < n;i++){
        if(arr[i] % 2 == 0){
            cnt++;
        }
    }
    return cnt;
     //*****************

