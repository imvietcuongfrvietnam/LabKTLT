#include <stdio.h>

int main() {
    int x, y, z;
    int *ptr;
    scanf("%d %d %d", &x, &y, &z);
    printf("Here are the values of x, y, and z:\n");
    printf("%d %d %d\n", x, y, z);
    //*****************
    //Trinh Viet Cuong 20224941
    ptr = &x;  //G�n dia chi cho bien x cho con tro ptr
    *ptr = *ptr + 100; //Th?c hi?n t?ng gi� tr? x l�n 100
    
    ptr = &y;  //G�n dia chi cho bien y cho con tro ptr
    *ptr = *ptr + 100; // Thuc hien tang gi� tro y l�n 100
    
    ptr = &z;  //G�n dia chi cho bien z cho con tro ptr
    *ptr = *ptr + 100; // Thuc hien tang gi� tro z l�n 100

    //*****************
    printf("Once again, here are the values of x, y, and z:\n");
    printf("%d %d %d\n", x, y, z);
    return 0;
}   

