# include <stdio.h>
int main(){
    int x, y, z;
    int* ptr;
    printf("Enter three integers: ");
    scanf("%d %d %d", &x, &y, &z);
    printf("\nThe three integers are:\n");
    ptr = &x; // gan dia chi cho bien con tro ptr
    printf("x = %d\n", *ptr);
    //*****************
    // Trinh Viet Cuong 20224941
    ptr = &y; // gan dia chi cho bien y cho con tro ptr
    printf("y = %d\n", *ptr);
    ptr = &z; // gan dia chi cho bien z cho con tro ptr
    printf("z =% d\n", *ptr);
   //*****************
   return 0;
}

