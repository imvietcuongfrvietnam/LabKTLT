#include <cstdio>
#include <iostream>
#include <cstdlib>
//Trinh Viet Cuong 20224941
using namespace std;

typedef struct _matrix { //Dinh nghia 1 ma tran vuong cap n
    int n;
    int **M;
} matrix;

void printMatrix(matrix mtx) { //Ham in ra ma tran
    for (int i = 0; i < mtx.n; i++) {
        for (int j = 0; j < mtx.n; j++) {
            printf("%d ", mtx.M[i][j]);
        }
        printf("\n");
    }
}

matrix scanMatrix(matrix &res, int n) { //Ham nhap vao va cap phat bo nho cho 1 ma tran vuong cap n
    res.n = n;
    res.M = (int **)malloc(res.n * sizeof(int *)); //Cap phat bo nho cho con tro ma tran
    if (res.M == NULL) {
        printf("Error mem allocation!\n");
        exit(1);
    }
    for (int i = 0; i < res.n; i++) {
        res.M[i] = (int *)malloc(res.n * sizeof(int));
        if (res.M[i] == NULL) {
            printf("Error!\n");
            exit(1);
        }
    }

    for (int i = 0; i < res.n; i++) {
        for (int j = 0; j < res.n; j++) {
            scanf("%d", &res.M[i][j]); 
        }
    }

    return res;
}

matrix operator+(matrix a, matrix b) { //Nap chong toan tu cong 2 ma tran tham so
    if (a.n != b.n) {
        printf("Khong the cong 2 ma tran khong cung co!!\n");
        exit(1);
    }
    matrix res;
    res.n = a.n;
    res.M = (int **)malloc(res.n * sizeof(int *));
    if (res.M == NULL) {
        printf("Error!\n");
        exit(1);
    }
    for (int i = 0; i < res.n; i++) {
        res.M[i] = (int *)malloc(res.n * sizeof(int));
        if (res.M[i] == NULL) {
            printf("Error!\n");
            exit(1);
        }
    }
    for (int i = 0; i < a.n; i++) {
        for (int j = 0; j < a.n; j++) {
            res.M[i][j] = a.M[i][j] + b.M[i][j];
        }
    }
    return res;
}

matrix operator*(matrix a, matrix b) { //Nap chong toan tu nhan 2 ma tran tham so 
    if (a.n != b.n) { //Neu 2 ma tran khac co thi khong the nhan
        printf("Khong the nhan 2 ma tran nay!!\n");
        exit(1);
    }
    matrix res;
    res.n = a.n;
    res.M = (int **)malloc(res.n * sizeof(int *));
    for (int i = 0; i < res.n; i++) {
        res.M[i] = (int *)malloc(res.n * sizeof(int));
    }
    for (int i = 0; i < res.n; i++) {
        for (int j = 0; j < res.n; j++) {
            res.M[i][j] = 0;
        }
    }
    for (int i = 0; i < a.n; i++) {
        for (int j = 0; j < b.n; j++) {
            for (int k = 0; k < a.n; k++) {
                res.M[i][j] += a.M[i][k] * b.M[k][j];
            }
        }
    }
    return res;
}

void freeMatrix(matrix a) { //Ham giai phong bo nho duoc cap phat dong cho ma tran sau khi lam viec xong
    for (int i = 0; i < a.n; i++) {
        free(a.M[i]); //Giai phong tung phan tu cua ma tran 
    }
    free(a.M);
}

int main() {
    int n;
    scanf("%d", &n);
    matrix a, b;
    scanMatrix(a, n);
    scanMatrix(b, n);
    matrix c = a + b;
    matrix d = a * b;
    printMatrix(c); //In ra ma tran c = tong 2 ma tran a va b
    printMatrix(d); //In ra ma tran d = tich 2 ma tran a va b
    freeMatrix(a); //Giai phong bo nho cap phat cho ma tran a
    freeMatrix(b); //Giai phong bo nho cap phat cho ma tran b
    freeMatrix(c); //Giai phong bo nho cap phap cho ma tran tong
    freeMatrix(d); //Giai phong bo nho cap phat cho ma tran tich
    return 0;
  
}

