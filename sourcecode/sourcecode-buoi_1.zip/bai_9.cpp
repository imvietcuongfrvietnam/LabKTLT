#include<stdio.h>
#include<stdlib.h>
//Trinh Viet Cuong 20224941

void printChillString(int *a, int n){ //Ham in ra cac day con su dung con tro va kich thuoc mang
    int k;
    int i = 0;
    while(i != n){ //Y tuong la in ra cac xau con bang cach dung vong lap while va cac vong for 
        int j = i; //i la phan tu khoi dau trong vong for
        while(j != n){ //j la phan tu ket thuc trong vong for
            for(k = i; k <= j; k++){  //Vong for in ra cac day con
                printf("%d ", *(a+k));
            }
            printf("\n");
            j++; //Tang thu tu phan tu ket thuc len
        }
        i++; //Tang thu tu phan tu khoi dau len
    }
}

int main(){
    int *a; //con tro dung de tao mang
    int n; //Kich thuoc mang
    scanf("%d", &n);
    a = (int*)malloc(n * sizeof(int)); //Cap phat dong cho mang n phan tu
    int i;
    for(i = 0; i < n; i++){
        scanf("%d", a+i); //Nhap vao
    }
    printChillString(a, n); //In ra day con
    free(a); // Giai phong bo nho da cap phat
}

