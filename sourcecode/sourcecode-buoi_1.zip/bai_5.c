double* maximum(double* a, int size){

    double *max;

    max = a;

    if (a==NULL) return NULL;


    //*****************
    //Trinh Viet Cuong 20224941
    int i;
    for(i = 1;i < size;i++){
        if(a[i] > *max) 
        max = a+i; 
    }
    
    //*****************

    return max;

}

