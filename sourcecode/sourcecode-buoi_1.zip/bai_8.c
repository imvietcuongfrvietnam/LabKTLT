#include<stdio.h>
#include<stdlib.h>

//Trinh Viet Cuong 20224941
void allocate_mem(int ***mt, int m, int n) {
    int **matrix = (int**)malloc(m * sizeof(int*)); 
    if (matrix == NULL) {
        printf("Error mem allocation"); 
        exit(1);
    }

    for (int i = 0; i < m; i++) {
        matrix[i] = (int*)malloc(n * sizeof(int)); 
        if (matrix[i] == NULL) {
            printf("Error mem allocation"); 
            exit(1);
        }
    }
    *mt = matrix; 
}

int countEven(int ***mt, int m, int n) {
    int count = 0;
    for (int i = 0; i < m; i++) {
        for (int j = 0; j < n; j++) {
            if ((*mt)[i][j] % 2 == 0) { 
                count += (*mt)[i][j]; 
            }
        }
    }
    return count;
}

int main() {
    int **mt; 
    int m, n;
    int i,j;
    printf("Enter m, n = ");
    scanf("%d %d", &m, &n);
    allocate_mem(&mt, m, n);
    for(i = 0;i < m;i++){
        for(j = 0;j < n;j++){
            printf("mt[%d][%d] = ",i,j);
        }
    }
    for (int i = 0; i < m; i++) {
        for (int j = 0; j < n; j++) {
            scanf("%d", &mt[i][j]);
        }
    }
    for (int i = 0; i < m; i++) {
        for (int j = 0; j < n; j++) {
            printf("%d ",mt[i][j]);
        }
        printf("\n");
    }
    int res = countEven(&mt, m, n);
    printf("The sum of all even elements is %d", res);
    
    // Free allocated memory
    for (int i = 0; i < m; i++) {
        free(mt[i]);
    }
    free(mt);

    return 0;
}


