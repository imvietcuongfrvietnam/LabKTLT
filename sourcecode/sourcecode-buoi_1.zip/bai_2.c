#include <stdio.h>

int main(){
    int a[7]= {13, -355, 235, 47, 67, 943, 1222}; 

    printf("address of first five elements in memory.\n");

    int i;
    for (i=0; i<5;i++)  printf("\t\t   a[%d] ",i);
    printf("\n");
    //*****************
    // Trinh Viet Cuong 20224941
    for(i=0;i<5;i++){
        printf("\t%p",&a[i]); 
    }
    //*****************     
    return 0;

