#include <stdio.h>
#include<stdlib.h>
    
    //Trinh Viet Cuong 20224941
void sort(int *a, int n){
    int tmp;
    int i,j;
    for(i = 0;i < n-1;i++){
        for(j = i+1;j < n;j++){
            if(*(a+i)>*(a+j)){ 
                tmp = *(a+i);
                *(a+i) = *(a+j);
                *(a+j) = tmp;
            }
        }
    }
}
int main() {
    int n;
    scanf("%d",&n); 
    int *a; 
    a = (int*)malloc(n * sizeof(int)); 
    if(a == NULL){
        printf("Error mem allocation"); 
        exit(1);
    }
    int i;
    for(i = 0;i < n;i++){
        scanf("%d",a+i);
    }
    printf("Enter the number of elements: The input array is:\n");
    for(i = 0;i < n;i++){
        printf("%d ",*(a+i));
    }
    printf("\n");
    printf("The sorted array is:\n");
    sort(a,n);
    for(i = 0;i < n;i++){
        printf("%d ",*(a+i));
    }
    return 0;
}   

